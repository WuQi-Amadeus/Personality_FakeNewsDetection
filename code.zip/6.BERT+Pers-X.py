import time
import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import BertTokenizer, BertModel
from Fix_Random_Seed import setup_seed

setup_seed(6666)
start_time = time.time()
neuron = 128
dic = {0: 'Ext', 1: 'Neu', 2: 'Agr', 3: 'Con', 4: 'Ope'}
for persid in range(5):
    saved_loss_path = 'saved-loss/Pers_{}_h{}_loss.txt'.format(dic[persid], neuron)
    saved_predict_path = 'saved-loss/Pers_{}_h{}_predict.txt'.format(dic[persid], neuron)


    def get_data(path):
        s = time.time()
        data = []
        with open(path, 'r', encoding='utf-8') as f:
            tmp = f.read().splitlines()
            for d in tmp:
                data.append(eval(d))
        f.close()
        input1, input2, label = [], [], []
        for d in data:
            input1.append(d[1])
            label.append(eval(d[0]))
            tmp = []
            for i in range(3, len(d)):
                rev_pers = eval(d[i])
                rev_pers = map(lambda x: (x-0.5)*2, rev_pers)
                tmp += rev_pers
            input2.append(tmp)

        # 将persid对应的人格置零
        for pers in input2:
            for i in range(persid, len(pers), 5):
                pers[i] = 0

        e = time.time()
        print('获取数据用时：{:.2f}秒'.format(e - s))
        return input1, input2, label


    class BERTClassifier(nn.Module):
        def __init__(self):
            super().__init__()
            self.model1_name = './used_model/chinese-bert-wwm'
            self.tokenizer = BertTokenizer.from_pretrained(self.model1_name)
            self.model1 = BertModel.from_pretrained(self.model1_name)

            self.fc1 = nn.Linear(768 + 400, neuron)
            self.fc2 = nn.Linear(neuron, 2)

        def forward(self, input1, input2):
            # 前向传播流程
            batch_tokenized = self.tokenizer.batch_encode_plus(input1,
                                                               add_special_tokens=True,
                                                               truncation=True,
                                                               max_length=200,
                                                               padding='max_length',
                                                               return_tensors='pt')
            input_ids = batch_tokenized['input_ids']
            attention_mask = batch_tokenized['attention_mask']
            hidden_outputs = self.model1(input_ids, attention_mask=attention_mask)
            out_puts = hidden_outputs[0][:, 0, :]

            tensor_input2 = torch.tensor(input2)
            combined = torch.cat((out_puts, tensor_input2), dim=1)
            x1 = F.relu(self.fc1(combined))
            predict_results = F.softmax(self.fc2(x1), dim=1)
            return predict_results


    if __name__ == '__main__':
        # 获取数据
        train_input1, train_input2, train_label = get_data('rumdect/data/train_data.txt')
        test_input1, test_input2, test_label = get_data('rumdect/data/test_data.txt')

        # 训练
        model = BERTClassifier()
        criterion = nn.CrossEntropyLoss()
        optimizer = torch.optim.Adam(model.parameters(), lr=2e-5)
        start_epoch = 0
        num_epochs = 10
        batch_size = 32
        batch_count = int(len(train_label) / batch_size)
        saved_loss = []

        '''
        # 加载参数
        saved_model_path = 'saved-model/Pers_h128_e4.pkl'
        checkpoint = torch.load(saved_model_path)
        model.load_state_dict(checkpoint['model_state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        start_epoch = checkpoint['epoch']+1
        '''

        for epoch in range(start_epoch, num_epochs):
            running_loss = 0.0
            tmp_loss = []
            for i in range(0, batch_size * batch_count, batch_size):
                input1 = train_input1[i: i + batch_size]
                input2 = train_input2[i: i + batch_size]
                label = train_label[i: i + batch_size]
                # 模型计算结果
                output = model(input1, input2)
                # 计算损失和梯度，更新模型参数
                loss = criterion(output, torch.tensor(label))
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                # 记录损失
                running_loss += loss.item()
                tmp_loss.append(loss.item())
                print("----Epoch:%d:  Batch:%d, 累计Loss %.4f" % (epoch, i / batch_size + 1, running_loss))
            epoch_loss = running_loss / batch_count
            saved_loss.append(tmp_loss)
            print("Epoch:%d: Loss %.4f" % (epoch, epoch_loss))

            # 保存训练的模型
            checkpoint = {'model_state_dict': model.state_dict(),
                          'optimizer_state_dict': optimizer.state_dict(),
                          'epoch': epoch}
            saved_model_path = 'saved-model/Pers_{}_h{}_e{}.pkl'.format(dic[persid], neuron, epoch)
            torch.save(checkpoint, saved_model_path)

        # 保存每轮的损失值
        with open(saved_loss_path, 'a', newline='', encoding='utf-8') as f:
            for d in saved_loss:
                f.write(str(d) + '\n')
        f.close()

        # 预测
        TP, TN, FP, FN = 0, 0, 0, 0
        total = len(test_label)
        with torch.no_grad():
            for i in range(total):
                print('\r测试集第', i, '篇新闻', end='')
                output = model([test_input1[i]], [test_input2[i]])
                _, predict = torch.max(output, 1)
                TP += 1 if predict == test_label[i] and test_label[i] == 1 else 0
                TN += 1 if predict == test_label[i] and test_label[i] == 0 else 0
                FP += 1 if predict != test_label[i] and test_label[i] == 0 else 0
                FN += 1 if predict != test_label[i] and test_label[i] == 1 else 0
            accuracy = float((TP + TN) / total)
            precision = float(TP / (TP + FP))
            recall = float(TP / (TP + FN))
            print()
            print('----------假新闻---真新闻--------')
            print('-预测正确--{}-----{}----'.format(TP, TN))
            print('-预测错误--{}-----{}----'.format(FP, FN))
            print('模型准确率：{:.2%}'.format(accuracy))
            print('模型查准率：{:.2%}'.format(precision))
            print('模型查全率：{:.2%}'.format(recall))
            print('模型F1得分：{:.2%}'.format(2 * precision * recall / (precision + recall)))

        end_time = time.time()
        print('训练用时：{:.2f}小时'.format((end_time - start_time)/3600))

        with open(saved_predict_path, 'w', newline='', encoding='utf-8') as f:
            f.write('---------假新闻---真新闻----' + '\n')
            f.write('-预测正确--{}-----{}----'.format(TP, TN) + '\n')
            f.write('-预测错误--{}-----{}----'.format(FP, FN) + '\n')
            f.write('模型准确率：' + str(accuracy) + '\n')
            f.write('模型查准率：' + str(precision) + '\n')
            f.write('模型查全率：' + str(recall))
        f.close()
